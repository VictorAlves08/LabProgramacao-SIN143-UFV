<!DOCTYPE html>
<html>
    <body>
        <form id="meuFormulario" action="">
            <label for="nome">Nome:</label><br>
            <input type="text" id="nome" name="nome"><br>
            <input type="submit" value="Submit">
        </form>
        
        <div id="resultado"></div>
        
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="meuScript.js"></script>
    </body>
</html>
