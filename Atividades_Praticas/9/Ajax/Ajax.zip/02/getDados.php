<?php
    echo "A hora atual é " . date('h:i:s');
?>
